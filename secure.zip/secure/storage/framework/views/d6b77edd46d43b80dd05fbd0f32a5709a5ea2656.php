<?php $__env->startSection('masthead'); ?>
    <?php $__env->startComponent('templates.components._masthead', [
        'image' => asset('assets/img/contact-bg.jpg'),
        'title' => 'List of Articles',
        'subtitle' => 'Best article for you'
    ]); ?>

    <?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="post-preview">
            <a href="<?php echo e(route('article.show', $article)); ?>">
                <h2 class="post-title">
                    <?php echo e($article->title); ?>

                </h2>
                <h3 class="post-subtitle">
                    <?php echo e(str_limit($article->body, 100)); ?>

                </h3>
            </a>
            <p class="post-meta">Posted by
            <a href="<?php echo e(route('profile.show', $article->user)); ?>"><?php echo e($article->user->name); ?></a>
            on <?php echo e($article->created_at); ?></p>
        </div>
        <?php if($article->user_id === session('id')): ?>
        <div class="row">
            <a href="<?php echo e(route('article.edit', $article)); ?>" class="btn btn-warning">Edit</a>
            <button id="delete" href="<?php echo e(route('article.destroy', $article)); ?>" class="btn btn-danger">Delete</button>
        </div>
        <?php endif; ?>
        <hr>
        <form action="" id="deleteForm" method="post">
            <?php echo csrf_field(); ?>
            <?php echo method_field("DELETE"); ?>
            <input type="submit" value="" style="display:none">
        </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>



    $('button#delete').on('click', function() {
        var href = $(this).attr('href');

        document.getElementById('deleteForm').action = href;
        document.getElementById('deleteForm').submit();
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('templates.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>