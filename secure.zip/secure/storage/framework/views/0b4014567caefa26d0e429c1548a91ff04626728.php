<?php $__env->startSection('masthead'); ?>
    <?php $__env->startComponent('templates.components._masthead', [
        'image' => asset('assets/img/contact-bg.jpg'),
        'title' => 'Register',
        'subtitle' => 'Create an account & Share your article'
    ]); ?>

    <?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <p>Publish your Article</p>
    <form action="<?php echo e(route('article.store')); ?>" name="sentMessage" id="registerForm" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="control-group">
            <div class="form-group floating-label-form-group controls">
                <label>Title</label>
                <input type="text" name="title" class="form-control" placeholder="Your title" id="title" required data-validation-required-message="Please enter your title." value="<?php echo e(old('title')); ?>">
                <?php if($errors->has('title')): ?>
                    <p class="help-block text-danger"><?php echo e($errors->first('title')); ?></p>
                <?php endif; ?>
            </div>
        </div>
        <div class="control-group">
            <div class="form-group floating-label-form-group controls">
                <label>Title</label>
                <input type="file" name="image" class="form-control" placeholder="Your image" id="image" data-validation-required-message="Please enter your title.">
                
            </div>
        </div>
        <div class="control-group">
          <div class="form-group floating-label-form-group controls">
            <label>Description</label>
            <textarea name="body" id="" cols="30" rows="5" class="form-control" placeholder="Write your content here..."><?php echo e(old('body')); ?></textarea>
            <?php if($errors->has('email')): ?>
              <p class="help-block text-danger"><?php echo e($errors->first('email')); ?></p>
            <?php endif; ?>
          </div>
        </div>
        <br>
        <div id="success"></div>
        <div class="form-group">
          <button type="submit" class="btn btn-primary" id="">Save</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>