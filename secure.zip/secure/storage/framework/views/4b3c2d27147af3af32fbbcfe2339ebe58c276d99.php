<?php $__env->startSection('masthead'); ?>
    <?php $__env->startComponent('templates.components._masthead', [
        'image' => asset('assets/uploads/'.$article->image),
        'title' => $article->title,
        'subtitle' => ''
    ]); ?>
        <span class="meta">Posted by
                <a href="#">
                    <?php echo e($article->name); ?>

                </a>
                on
                <?php echo e($article->created_at); ?>

        </span>
    <?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<article>
    <div class="container">
        <div class="row">
            <p><?php echo e($article->body); ?></p>
        </div>
    </div>
</article>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>