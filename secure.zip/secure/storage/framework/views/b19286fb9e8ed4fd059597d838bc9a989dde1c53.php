<?php $__env->startSection('masthead'); ?>
    <?php $__env->startComponent('templates.components._masthead', [
        'image' => asset('assets/img/contact-bg.jpg'),
        'title' => 'Update Profile '. $user->name,
        'subtitle' => 'Update your Profile'
    ]); ?>

    <?php echo $__env->renderComponent(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <p>Update your Profile</p>
    <form action="<?php echo e(route('profile.update')); ?>" name="sentMessage" id="registerForm" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field("PUT"); ?>
        <div class="control-group">
            <div class="form-group floating-label-form-group controls">
                <label>Name</label>
                <input type="text" name="name" class="form-control" placeholder="Your title" id="title" required data-validation-required-message="Please enter your name." value="<?php echo e(old('name') ?? $user->name); ?>">
                <?php if($errors->has('name')): ?>
                    <p class="help-block text-danger"><?php echo e($errors->first('name')); ?></p>
                <?php endif; ?>
            </div>
        </div>
        <div class="control-group">
            <div class="form-group floating-label-form-group controls">
                <label>Email</label>
                <input type="email" name="email" class="form-control" placeholder="Your title" id="title" required data-validation-required-message="Please enter your email." value="<?php echo e(old('email') ?? $user->email); ?>">
                <?php if($errors->has('email')): ?>
                    <p class="help-block text-danger"><?php echo e($errors->first('email')); ?></p>
                <?php endif; ?>
            </div>
        </div>
        <div class="control-group">
            <div class="form-group floating-label-form-group controls">
                <label>Title</label>
                <input type="password" name="password" class="form-control" placeholder="Your pasword" id="title" >
                <?php if($errors->has('password')): ?>
                    <p class="help-block text-danger"><?php echo e($errors->first('password')); ?></p>
                <?php endif; ?>
            </div>
        </div>
        <br>
        <div id="success"></div>
        <div class="form-group">
          <button type="submit" class="btn btn-primary" id="">Update</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>