
<!DOCTYPE html>
<html lang="en">

  <?php echo $__env->make('templates.partials._head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <body>

    <!-- Navigation -->
    <?php echo $__env->make('templates.partials._navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <!-- Page Header -->
    <header class="masthead" style="background-image: url('<?php echo e(asset('assets/img/home-bg.jpg')); ?>')">
      <div class="overlay"></div>
      <div class="container">
        <div class="row">
          <div class="col-lg-8 col-md-10 mx-auto">
            <div class="site-heading">
              <h1>Secure Coding</h1>
              <span class="subheading">Blog Percobaan untuk Workshop Secure Coding</span>
            </div>
          </div>
        </div>
      </div>
    </header>

    <!-- Main Content -->
    <div class="container">
      <div class="row">
        <div class="col-lg-8 col-md-10 mx-auto">

          <?php echo $__env->yieldContent('content'); ?>

          <hr>
          <!-- Pager -->
          
        </div>
      </div>
    </div>

    <hr>

    <!-- Footer -->
    <?php echo $__env->make('templates.partials._footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  </body>

</html>
