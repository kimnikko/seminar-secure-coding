@extends('templates.default')

@section('masthead')
    @component('templates.components._masthead', [
        'image' => asset('assets/img/contact-bg.jpg'),
        'title' => 'Register',
        'subtitle' => 'Create an account & Share your article'
    ])

    @endcomponent
@endsection

@section('content')
    <p>Publish your Article</p>
    <form action="{{ route('article.update', $article) }}" name="sentMessage" id="registerForm" method="post" enctype="multipart/form-data">
        @csrf
        @method("PUT")
        <div class="control-group">
            <div class="form-group floating-label-form-group controls">
                <label>Title</label>
                <input type="text" name="title" class="form-control" placeholder="Your title" id="title" required data-validation-required-message="Please enter your title." value="{{ $article->title ?? old('title') }}">
                @if ($errors->has('title'))
                    <p class="help-block text-danger">{{ $errors->first('title') }}</p>
                @endif
            </div>
        </div>
        <div class="control-group">
            <div class="form-group floating-label-form-group controls">
                <label>Title</label>
                <input type="file" name="image" class="form-control" placeholder="Your image" id="image" data-validation-required-message="Please enter your title.">
                {{-- @if ($errors->has('title'))
                    <p class="help-block text-danger">{{ $errors->first('title') }}</p>
                @endif --}}
            </div>
        </div>
        <div class="control-group">
          <div class="form-group floating-label-form-group controls">
            <label>Description</label>
            <textarea name="body" id="" cols="30" rows="5" class="form-control" placeholder="Write your content here...">{{ $article->body ?? old('body') }}</textarea>
            @if ($errors->has('email'))
              <p class="help-block text-danger">{{ $errors->first('email') }}</p>
            @endif
          </div>
        </div>
        <br>
        <div id="success"></div>
        <div class="form-group">
          <button type="submit" class="btn btn-primary" id="">Update</button>
        </div>
    </form>
@endsection